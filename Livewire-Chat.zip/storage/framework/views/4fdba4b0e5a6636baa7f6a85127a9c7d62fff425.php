<div wire:poll>
<div class="container">
  <h3 class=" text-center">  
    
    <?php if(auth()->user()->email == "samir.gamal77@yahoo.com"): ?>
    <a class="btn btn-primary" href="<?php echo e(Url('delete_chat')); ?>">حذف المحادثة</a>
    <?php endif; ?>
        
    مورا سوفت 
  
  </h3>
 
  <div class="messaging">
        <div  class="inbox_msg">
          <div  class="mesgs">
            <div id="chat" class="msg_history">
              <?php $__empty_1 = true; $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

              <?php if($message->user->name == auth()->user()->name): ?>
                  <!-- Reciever Message-->
                      <div class="outgoing_msg">
                        <div class="sent_msg">
                          <p><?php echo e($message->message_text); ?></p>
                          <span class="time_date"> <?php echo e($message->created_at->diffForHumans(null, false, false)); ?></span> </div>
                         

                      </div>
                      
              <?php else: ?>
                
                      <div class="incoming_msg"><?php echo e($message->user->name); ?>

                        <div class="incoming_msg_img"> <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil"> </div>
                        <div class="received_msg">
                          <div class="received_withd_msg">
                            <p><?php echo e($message->message_text); ?></p>
                            <span class="time_date"><?php echo e($message->created_at->diffForHumans(null, false, false)); ?></span></div>
                        </div>
                      </div>

                  <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                 <h5 style="text-align: center;color:red"> لاتوجد رسائل سابقة</h5>
              <?php endif; ?>

            </div>
            <div class="type_msg">
              <div class="input_msg_write">
                <form wire:submit.prevent="sendMessage">
                  <input onkeydown='scrollDown()' wire:model.defer="messageText" type="text" class="write_msg" placeholder="اكتب رسالتك" />
                  <button class="msg_send_btn" type="submit">ارسال</button>
                </form>
              </div>
            </div>
        
          </div>
        </div>
    
      </div>
    </div>
  </div>


<?php /**PATH C:\Users\SAMIR\OneDrive\laravel\Livewire-Chat\resources\views/livewire/chat.blade.php ENDPATH**/ ?>